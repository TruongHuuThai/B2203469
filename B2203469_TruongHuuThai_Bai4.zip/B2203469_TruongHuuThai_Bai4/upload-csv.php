<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upload CSV File</title>
</head>
<body>
    <h2>Upload CSV File</h2>
    <!-- Lưu ý: enctype="multipart/form-data" là bắt buộc để upload file -->
    <form action="upload-csv-processing.php" method="post" enctype="multipart/form-data">
        Chọn tập tin CSV để upload:
        <input type="file" name="csvFile" id="csvFile" accept=".csv">
        <br><br>
        <input type="submit" value="Upload CSV" name="submit">
    </form>
</body>
</html>
