<?php
session_start();

// Kiểm tra xem người dùng đã đăng nhập hay chưa
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Xử lý khi form được submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ form
    $old_pass = trim($_POST["old_pass"]);
    $new_pass = trim($_POST["new_pass"]);
    $confirm_pass = trim($_POST["confirm_pass"]);

    // Kiểm tra các trường không được để trống
    if (empty($old_pass) || empty($new_pass) || empty($confirm_pass)) {
        echo "Vui lòng điền đầy đủ thông tin.";
    } elseif ($new_pass !== $confirm_pass) {
        // Kiểm tra mật khẩu mới và xác nhận có khớp nhau không
        echo "Mật khẩu mới và xác nhận không khớp.";
    } else {
        // Kết nối đến cơ sở dữ liệu
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "qlbanhang";
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Kết nối thất bại: " . $conn->connect_error);
        }

        // Lấy id người dùng từ session
        $user_id = $_SESSION['id'];

        // Lấy mật khẩu hiện tại của người dùng từ DB (giả sử mật khẩu được lưu trong cột "password" của bảng "customers")
        $stmt = $conn->prepare("SELECT password FROM customers WHERE id = ?");
        if (!$stmt) {
            die("Lỗi chuẩn bị câu lệnh: " . $conn->error);
        }
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($current_hashed_password);
        $stmt->fetch();
        $stmt->close();

        // Kiểm tra mật khẩu cũ có khớp hay không
        if ($current_hashed_password !== md5($old_pass)) {
            echo "Mật khẩu cũ không đúng.";
        } elseif (md5($new_pass) === $current_hashed_password) {
            echo "Mật khẩu mới phải khác mật khẩu cũ.";
        } else {
            // Băm mật khẩu mới với md5
            $new_hashed_password = md5($new_pass);

            // Cập nhật mật khẩu mới vào DB
            $update_stmt = $conn->prepare("UPDATE customers SET password = ? WHERE id = ?");
            if (!$update_stmt) {
                die("Lỗi chuẩn bị câu lệnh cập nhật: " . $conn->error);
            }
            $update_stmt->bind_param("si", $new_hashed_password, $user_id);
            if ($update_stmt->execute()) {
                echo "Mật khẩu đã được cập nhật thành công.";
            } else {
                echo "Có lỗi xảy ra khi cập nhật mật khẩu.";
            }
            $update_stmt->close();
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Chỉnh sửa mật khẩu</title>
</head>
<body>
    <h2>Chỉnh sửa mật khẩu</h2>
    <form action="sua_mk.php" method="post">
        <label for="old_pass">Mật khẩu cũ:</label>
        <input type="password" name="old_pass" id="old_pass" required><br><br>

        <label for="new_pass">Mật khẩu mới:</label>
        <input type="password" name="new_pass" id="new_pass" required><br><br>

        <label for="confirm_pass">Xác nhận mật khẩu mới:</label>
        <input type="password" name="confirm_pass" id="confirm_pass" required><br><br>

        <input type="submit" value="Cập nhật mật khẩu">
    </form>
</body>
</html>
