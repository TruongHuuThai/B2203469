<?php
session_start(); // Khởi tạo session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Kiểm tra dữ liệu POST
if (isset($_POST['email']) && isset($_POST['pass'])) {
    $email = $_POST['email'];
    $pass = md5($_POST['pass']); 

    // Sử dụng Prepared Statement
    $stmt = $conn->prepare("SELECT id, fullname, email FROM customers WHERE email = ? AND password = ?");
    if (!$stmt) {
        die("Lỗi trong quá trình chuẩn bị câu lệnh: " . $conn->error);
    }
    $stmt->bind_param("ss", $email, $pass);

    // Thực thi câu lệnh
    $stmt->execute();

    // Lấy kết quả
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Lưu thông tin đăng nhập vào session
        $_SESSION["user"] = $row["email"];
        $_SESSION["fullname"] = $row["fullname"];
        $_SESSION["id"] = $row["id"];
        header('Location: homepage.php');
    } else {
        echo "Email hoặc mật khẩu không đúng.";
        header('Refresh: 3;url=login.php');
    }

    // Đóng câu lệnh
    $stmt->close();
} else {
    echo "Vui lòng nhập email và mật khẩu.";
    header('Refresh: 3;url=login.php');
}

$conn->close();
?>
