<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == UPLOAD_ERR_OK) {
    $target_dir = "uploads/";

    // Tạo thư mục nếu chưa tồn tại
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Lấy thông tin file
    $imageFileType = strtolower(pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION));
    $target_file = $target_dir . uniqid() . "." . $imageFileType;
    $uploadOk = 1;

    // Kiểm tra có phải là ảnh không
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if ($check !== false) {
        echo "File là ảnh - " . $check["mime"] . ".<br>";
    } else {
        echo "File không phải là ảnh.<br>";
        $uploadOk = 0;
    }

    // Kiểm tra kích thước (500KB)
    if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "File quá lớn (tối đa 500KB).<br>";
        $uploadOk = 0;
    }

    // Chỉ cho phép định dạng JPG, JPEG, PNG, GIF
    if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
        echo "Chỉ chấp nhận file JPG, JPEG, PNG & GIF.<br>";
        $uploadOk = 0;
    }

    // Nếu không có lỗi, thực hiện upload
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "File đã được tải lên: " . htmlspecialchars(basename($target_file)) . "<br>";
        } else {
            echo "Lỗi khi tải lên.<br>";
        }
    } else {
        echo "File không được tải lên do lỗi.<br>";
    }
} else {
    echo "Không có file nào được tải lên hoặc xảy ra lỗi.<br>";
}
?>