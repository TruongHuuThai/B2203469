<?php
// upload-csv-processing.php

// Kiểm tra xem form đã được submit hay chưa
if(isset($_POST["submit"])) {

    // Thiết lập thư mục lưu file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["csvFile"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Kiểm tra loại file: chỉ cho phép file CSV
    if($fileType != "csv") {
        echo "Chỉ chấp nhận tập tin CSV.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        echo "Tập tin không được upload.";
    } else {
        if (move_uploaded_file($_FILES["csvFile"]["tmp_name"], $target_file)) {
            echo "Tập tin ". htmlspecialchars(basename($_FILES["csvFile"]["name"])) . " đã được upload thành công.<br>";

            // Kết nối đến CSDL
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "qlbanhang";

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Kết nối thất bại: " . $conn->connect_error);
            }

            // Mở file CSV và đọc dữ liệu theo từng dòng
            if (($handle = fopen($target_file, "r")) !== FALSE) {
                // Nếu file CSV có header (dòng tiêu đề) thì bỏ qua dòng đầu tiên:
                // fgetcsv($handle, 1000, ",");

                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    // Giả sử cấu trúc của file CSV là:
                    // fullname, email, password
                    // Chú ý: Bạn cần đảm bảo rằng CSV có đúng số cột và thứ tự như vậy.
                    $fullname = $conn->real_escape_string($data[0]);
                    $email = $conn->real_escape_string($data[1]);
                    // Băm mật khẩu bằng md5 (đảm bảo rằng CSDL của bạn lưu mật khẩu theo định dạng này)
                    $password_csv = md5($conn->real_escape_string($data[2]));

                    // Tạo câu lệnh INSERT để đưa dữ liệu vào bảng customers
                    $sql = "INSERT INTO customers (fullname, email, password) VALUES ('$fullname', '$email', '$password_csv')";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "Đã thêm dữ liệu: $fullname, $email <br>";
                    } else {
                        echo "Lỗi: " . $sql . "<br>" . $conn->error . "<br>";
                    }
                }
                fclose($handle);
            } else {
                echo "Không thể mở tập tin CSV.";
            }
            $conn->close();
        } else {
            echo "Có lỗi khi upload tập tin CSV.";
        }
    }
} else {
    echo "Vui lòng upload tập tin CSV.";
}
?>
