 
<?php 
// thong tin ve chuoi ket noi gom server name, username va mat khau de dang nhap vao mysql, mac dinh cua xampp la root, password rong 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password); 
  
 
// Check connection 
if ($conn->connect_error) { 
    while($row = $result->fetch_assoc()) {     
        echo "id: " . $row["id"]. " - Hoten: " . $row["fullname"]. " " . 
        $row["email"].' ngaysinh: '.$row['Birthday']. "<br>"; 
          }   
          echo '<br>';   echo '<br>'; 
          //xoa ket qua cu tu o tren 
          $result -> free_result(); 
        
} 
//neu ket noi thanh cong 
echo "Connected successfully"; 
?> 
