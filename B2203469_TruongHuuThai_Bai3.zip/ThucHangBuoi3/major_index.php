<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Kết nối CSDL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Lấy danh sách chuyên ngành
$sql = "SELECT * FROM major";
$result = $conn->query($sql);
echo "<h2>Danh sách chuyên ngành</h2>";
echo "<a href='major_add.php'>Thêm chuyên ngành mới</a><br><br>";
if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Tên chuyên ngành</th>
                <th>Hành động</th>
            </tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["id"]. "</td>
                <td>" . $row["name_major"]. "</td>
                <td>
                    <a href='major_edit.php?id=" . $row["id"] . "'>Sửa</a> | 
                    <a href='major_xoa.php?id=" . $row["id"] . "'>Xóa</a>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "Không có dữ liệu";
}
$conn->close();
?>
