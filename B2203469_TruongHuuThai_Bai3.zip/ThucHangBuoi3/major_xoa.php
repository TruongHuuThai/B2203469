<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Xóa chuyên ngành theo ID
    $sql = "DELETE FROM major WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Chuyên ngành đã được xóa thành công.";
        header("Location: major_index.php");  // Chuyển hướng về trang danh sách chuyên ngành
        exit;
    } else {
        echo "Lỗi: " . $conn->error;
    }
}

$conn->close();
?>
