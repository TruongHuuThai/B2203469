<?php
$serverName = "tcp:myserver.database.windows.net,1433";
$connectionOptions = array(
    "Database" => "AdventureWorks",
    "Uid" => "MyUser",
    "PWD" => "MyPassword"
);
$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
} else {
    echo "Kết nối thành công!";
}
?>
