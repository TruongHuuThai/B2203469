<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name_major = $_POST['name_major'];

    // Chèn dữ liệu vào bảng major
    $sql = "INSERT INTO major (name_major) VALUES ('$name_major')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Chuyên ngành đã được thêm thành công.";
        header("Location: major_index.php");  // Chuyển hướng về trang danh sách chuyên ngành
        exit;
    } else {
        echo "Lỗi: " . $conn->error;
    }   
}

$conn->close();
?>
