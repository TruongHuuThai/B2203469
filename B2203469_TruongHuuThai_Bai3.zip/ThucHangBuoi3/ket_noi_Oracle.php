<?php
$conn = oci_connect('username', 'password', 'localhost/XE');
if (!$conn) {
    $e = oci_error();
    echo "Kết nối thất bại: " . $e['message'];
} else {
    echo "Kết nối thành công!";
}
?>
