<?php
echo "<h2>Thêm chuyên ngành mới</h2>";
?>
<form action="major_add_save.php" method="post">
    <label for="name_major">Tên chuyên ngành:</label><br>
    <input type="text" id="name_major" name="name_major" required><br><br>
    <input type="submit" value="Thêm">
</form>
