<?php 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "qlsv"; 

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {   
    die("Connection failed: " . $conn->connect_error); 
}

// Truy vấn để lấy dữ liệu sinh viên và tên chuyên ngành từ bảng major
$sql = "SELECT student.*, major.name_major FROM student LEFT JOIN major ON student.major_id = major.id"; 
$result = $conn->query($sql); 

if ($result->num_rows > 0) {    
    // Lấy tất cả kết quả dưới dạng mảng liên kết
    $result_all = $result->fetch_all(MYSQLI_ASSOC); 
?> 

<h1>Danh sách sinh viên</h1> 
<table border="1">
  <tr>
    <th>ID</th>
    <th>Họ và tên</th>
    <th>Email</th>
    <th>Ngày sinh</th>
    <th>Chuyên ngành</th>
    <th colspan="2">Hành động</th>
  </tr>
<?php     
    // Lặp qua tất cả kết quả sinh viên
    foreach ($result_all as $row) { 
        // Chuyển đổi định dạng ngày tháng
        $date = date_create($row['Birthday']); 
        echo "<tr>
                <td>" . $row["id"] . "</td>
                <td>" . $row["fullname"] . "</td>
                <td>" . $row["email"] . "</td>
                <td>" . $date->format('d-m-Y') . "</td>
                <td>" . $row['name_major'] . "</td>
                <td>"; 
?> 
        <!-- Form xóa sinh viên -->
        <form method="post" action="xoa.php">  
            <input type="submit" name="action" value="Xóa"/>  
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/> 
        </form> 
<?php      
        echo "</td><td>"; 
?> 
        <!-- Form sửa sinh viên -->
        <form method="post" action="form_sua.php">  
            <input type="submit" name="action" value="Sửa"/>  
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/> 
        </form> 
<?php      
        echo "</td></tr>"; 
    } 
    echo "</table>"; 
} else {   
    echo "Không có kết quả nào được tìm thấy."; 
}

$conn->close(); 
?>
