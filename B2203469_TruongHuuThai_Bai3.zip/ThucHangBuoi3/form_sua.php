<!DOCTYPE HTML>
<html>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Lấy ID sinh viên từ POST
$id = $_POST['id'];
$sql = "SELECT * FROM student WHERE id='" . $id . "'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<body>

<form action="sua.php" method="post">
    ID: <input type="text" name="id" value="<?php echo $row['id']; ?>" readonly><br>
    Name: <input type="text" name="fullname" value="<?php echo $row['fullname']; ?>"><br>
    E-mail: <input type="text" name="email" value="<?php echo $row['email']; ?>"><br>
    Birthday: <input type="date" name="birth" value="<?php echo $row['Birthday']; ?>"><br>

    <!-- Thêm combobox để chọn chuyên ngành -->
    Chuyên Ngành:
    <select name="major_id">
        <?php
        // Lấy danh sách chuyên ngành từ bảng major
        $sql_major = "SELECT * FROM major";
        $result_major = $conn->query($sql_major);

        // Kiểm tra nếu có chuyên ngành
        if ($result_major->num_rows > 0) {
            // Hiển thị các chuyên ngành trong combobox
            while ($major = $result_major->fetch_assoc()) {
                $selected = ($row['major_id'] == $major['id']) ? "selected" : "";
                echo "<option value='" . $major['id'] . "' $selected>" . $major['name_major'] . "</option>";
            }
        } else {
            echo "<option value=''>Không có chuyên ngành</option>";
        }

        $conn->close();
        ?>
    </select><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>
