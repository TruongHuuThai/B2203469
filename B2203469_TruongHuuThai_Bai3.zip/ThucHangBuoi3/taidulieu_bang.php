<?php 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "qlsv"; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
// Check connection 
if ($conn->connect_error) {   
    die("Connection failed: " . $conn->connect_error); 
} 
//tao chuoi luu cau lenh sql 
$sql = "SELECT * FROM student"; 
//thuc thi cau lenh sql va dua doi tuong vao $result 
$result = $conn->query($sql); 
if ($result->num_rows > 0) {
    // Trình bày dữ liệu trong một bảng HTML
    echo "<table border='1'><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Ngày sinh</th></tr>"; 

    // Duyệt qua các kết quả
    while ($row = $result->fetch_row()) { 
        // Định dạng ngày tháng theo dd-mm-yyyy
        $date = date_create($row[3]); 

        echo "<tr><td>" . $row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td><td>" .  
        $date->format('d-m-Y') . "</td></tr>"; 
    } 
    
    echo "</table>"; 
   }
$conn->close(); 
?> 

