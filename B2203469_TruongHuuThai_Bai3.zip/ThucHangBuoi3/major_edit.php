<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Lấy thông tin chuyên ngành theo ID
    $sql = "SELECT * FROM major WHERE id=$id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name_major = $row['name_major'];
    } else {
        echo "Không tìm thấy chuyên ngành!";
        exit;
    }
} else {
    echo "ID không hợp lệ!";
    exit;
}

$conn->close();
?>

<h2>Sửa chuyên ngành</h2>
<form action="major_edit_save.php" method="post">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <label for="name_major">Tên chuyên ngành:</label><br>
    <input type="text" id="name_major" name="name_major" value="<?php echo $name_major; ?>" required><br><br>
    <input type="submit" value="Lưu thay đổi">
</form>
