<!DOCTYPE HTML>
<html>
<body>

<form action="luu.php" method="post">
    Name: <input type="text" name="name"><br>
    E-mail: <input type="text" name="email"><br>
    Birthday: <input type="date" name="birth"><br>

    <!-- Thêm combobox để chọn chuyên ngành -->
    Chuyên Ngành:
    <select name="major_id">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "qlsv";

        // Tạo kết nối
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Kiểm tra kết nối
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Lấy danh sách chuyên ngành từ bảng major
        $sql = "SELECT * FROM major";
        $result = $conn->query($sql);

        // Kiểm tra nếu có chuyên ngành
        if ($result->num_rows > 0) {
            // Hiển thị các chuyên ngành trong combobox
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['id'] . "'>" . $row['name_major'] . "</option>";
            }
        } else {
            echo "<option value=''>Không có chuyên ngành</option>";
        }

        $conn->close();
        ?>
    </select><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>
